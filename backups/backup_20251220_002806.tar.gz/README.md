# Git Labor Projekt

**Autor:** Simon Palu  
**Kuupäev:** 2025-12-20

## Eesmärk

Õppida Git workflow'sid, branch'e ja koostööd GitHub'iga.

## Tehnoloogiad

- Git
- GitHub
- Bash
